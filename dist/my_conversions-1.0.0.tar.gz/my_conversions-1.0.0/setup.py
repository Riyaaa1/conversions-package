from setuptools import setup
setup(
    name='my_conversions',
    version='1.0.0',
    description="A dummy unit conversions package",
    author="Riya",
    author_email="lcsmriti@gmail.com",
    packages=['my_conversions'],
    python_requires = '>=3.10',
    install_requires =[],
    license='MIT'
)